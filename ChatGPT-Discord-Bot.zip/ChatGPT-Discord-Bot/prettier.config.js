/** @type {import('prettier').Config} */
module.exports = {
  singleQuote: true,
};
